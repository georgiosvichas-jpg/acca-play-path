
ACCA Seed Pack – Syllabus-aligned data and original mini-problems
-----------------------------------------------------------------
Files:
- papers.csv
- syllabus_units.csv (~40 units per paper)
- flashcards.csv (50 original items per paper; no reproduction of ACCA questions)
- past_papers_meta.csv (metadata only; no question text)
Note: Topic scaffolds reflect the public ACCA syllabus headings; wording is original.
